WELCOME_MESSAGE = "Welcome to deebee!"

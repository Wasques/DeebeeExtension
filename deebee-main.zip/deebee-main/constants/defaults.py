EMPTY_STRING = ""
EMPTY_LIST = list()
EMPTY_DICT = dict()

SUPPORTED_DATASET_TYPES = ["csv", "xlsx"]
SUPPORTED_CORRECTION_DATA_TYPES = [
    "int",
    "uint",
    "bool",
    "float",
    "str",
]